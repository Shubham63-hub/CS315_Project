import * as React from 'react';
import Navbar from '../components/Navbar';
import LoginForm from '../components/LoginForm';

function Login() {
    // const centerMaking ;
    return (
        <div >
                <Navbar/>
                <LoginForm/>
        </div>

    )
}

export default Login