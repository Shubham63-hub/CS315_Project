import React from 'react'
import Navbar from '../components/Navbar'
import AddQuiz from '../components/AddQuiz'

function AddQuizPage() {
  return (
    <div>
        <Navbar/>
        <AddQuiz />
    </div>
  )
}

export default AddQuizPage
