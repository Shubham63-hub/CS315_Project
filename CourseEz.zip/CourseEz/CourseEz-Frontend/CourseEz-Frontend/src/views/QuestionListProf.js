import * as React from "react";
import Navbar from "../components/Navbar";
import { QuestionsListProf } from "../components/QuestionsListProf";

function QuestionListProf() {
  // const centerMaking ;
  return (
    <div>
      <Navbar />
      <QuestionsListProf />
    </div>
  );
}

export default QuestionListProf;
