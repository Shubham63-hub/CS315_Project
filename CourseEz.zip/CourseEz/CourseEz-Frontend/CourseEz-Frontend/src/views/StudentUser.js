import * as React from 'react';
import Navbar from '../components/Navbar';
import StudentDetails from '../components/StudentDetails';

function StudentUser() {
    return (
        <div >
                <Navbar/>
                <StudentDetails/>
        </div>
    )
}

export default StudentUser