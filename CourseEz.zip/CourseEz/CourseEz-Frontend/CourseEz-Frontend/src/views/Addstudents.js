import React from 'react'
import Navbar from "../components/Navbar"
import AddStudentsPage from '../components/AddStudentsPage'

function Addstudents() {
  return (
    <div>
      <Navbar/>
      <AddStudentsPage/>
    </div>
  )
}

export default Addstudents
