import React from 'react'
import Navbar from "../components/Navbar"
import Course from '../components/Course'

function CoursePage() {
  return (
    <div>
        <Navbar />
        <Course />
    </div>
  )
}

export default CoursePage
