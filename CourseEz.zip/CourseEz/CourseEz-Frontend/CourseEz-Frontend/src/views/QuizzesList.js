import React from 'react'
import Quizzes from '../components/Quizzes'
import Navbar from '../components/Navbar'

function QuizzesList() {
  return (
    <div>
        <Navbar/>
        <Quizzes/>
    </div>
  )
}

export default QuizzesList
