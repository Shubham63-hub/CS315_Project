import * as React from "react";
import { Typography, Paper, IconButton } from "@mui/material";
import { Button } from "@mui/material";
import Dialog from "@mui/material/Dialog";
import Logo from "../images/studentLogo.svg";
import PlusLogo from "../images/plusLogo.svg";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";

export default function StudentDetails() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const [props, setProps] = React.useState({
    name: "?",
    rollno: "?",
    programme: "?",
    dept: "?",
  });
  const [courses, setCourses] = React.useState([]);
  const [profs, setProfs] = React.useState([]);
  const [open, setOpen] = React.useState(false);
  const [courseNo, setCourseNo] = React.useState("");
  const [courseTitle, setCourseTitle] = React.useState("");
  const [addResponse, setAddResponse] = React.useState();

  React.useEffect(() => {
    // get user info
    axios
      .post("http://localhost:8080/userinfo", null, {
        params: { userId: state.userId },
      })
      .then((res) => {
        setProps({ ...res.data });
      });

    // get user's courses
    axios
      .post("http://localhost:8080/getcourses", null, {
        params: { userId: state.userId },
      })
      .then((res) => {
        setCourses(res.data);
      });

    // get course profs
    axios.post("http://localhost:8080/getprofs", courses).then((res) => {
      setProfs(res.data);
    });
  });

  const handleAdd = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:8080/addcourse", null, {
        params: {
          profId: state.userId,
          courseNo: courseNo,
          courseTitle: courseTitle,
        },
      })
      .then((res) => {
        setAddResponse(res.data);
      });
  };

  const centerMaking = {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
  };

  const leftAlign = {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "flex-start",
  };

  const imageCentre = {
    transform: "scale(1)",
    marginRight: "20px",
  };

  const courseNavigater = (course) => {
    console.log(course.name);
  };

  return (
    <div style={centerMaking}>
      <div
        style={{
          margin: 10,
          marginTop: "40px",
          display: "flex",
          flexDirection: "row",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        {/* user details */}
        <img src={Logo} alt="studnet logo" style={imageCentre} />
        <div height="100%" style={leftAlign}>
          <Typography variant="h6">Name: {props.name}</Typography>
          <Typography variant="h6">Roll No.: {props.rollno}</Typography>
          <Typography variant="h6">Programme: {props.programme}</Typography>
          <Typography variant="h6">Department: {props.dept}</Typography>
        </div>
      </div>

      {/* user courses */}
      <h2 width="500" text-align="left">
        Courses
      </h2>
      <hr
        style={{
          width: "90%",
          height: 1,
          color: "black",
          backgroundColor: "black",
        }}
      />
      <div
        style={{
          width: "90%",
          display: "flex",
          flexDirection: "row",
          justifyContent: "center",
          flexWrap: "wrap",
        }}
      >
        {
          // course list
          courses.map((it, i) =>
            it != null ? (
              <div
                onClick={() => {
                  navigate("/coursepage", {
                    state: {
                      isProf: state.isProf,
                      userId: state.userId,
                      courseId: it.courseId
                    }
                  });
                  console.log(it.courseId);
                }}
              >
                <Paper
                  elevation={6}
                  sx={{
                    height: 200,
                    width: 300,
                    borderRadius: 10,
                    display: "flex",
                    alignItems: "center",
                    postion: "relative",
                    flexDirection: "column",
                    margin: 1,
                    ":hover": {
                      cursor: "pointer",
                      transform: "scale(1.01)",
                    },
                    key: { i },
                  }}
                >
                  <h2> {it.courseNo + ": " + it.courseTitle} </h2>
                  <hr
                    style={{
                      width: "90%",
                      height: 1,
                      color: "black",
                      backgroundColor: "black",
                    }}
                  />
                  <p style={{ fontSize: "1.1em" }}> {profs[i]} </p>
                </Paper>
              </div>
            ) : null
          )
        }

        {/* user is prof so add course */}
        {state.isProf ? (
          <div
            onClick={() => {
              setOpen(true);
            }}
          >
            <Paper
              elevation={6}
              sx={{
                height: 200,
                width: 300,
                borderRadius: 10,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                margin: 1,
                ":hover": {
                  cursor: "pointer",
                  transform: "scale(1.01)",
                },
              }}
              onclick={() => {
                console.log("working");
                setOpen(true);
              }}
            >
              <img
                height="40%"
                src={PlusLogo}
                alt="studnet logo"
                style={{ transform: "scale(0.5)" }}
              />
              <p>Add Course</p>
            </Paper>
          </div>
        ) : null}
      </div>
      <Dialog
        open={open}
        onClose={() => {
          setOpen(false);
          setAddResponse(undefined);
        }}
        style={{
          borderRadius: 10,
        }}
      >
        <div
          style={{
            padding: 60,
            borderRadius: "300px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <h2>Course Details</h2>
          {addResponse == undefined ? (
            <></>
          ) : addResponse == false ? (
            <p style={{ color: "red" }}> Course already exists.</p>
          ) : (
            <p style={{ color: "green" }}> Course added successfully.</p>
          )}
          <input
            style={{
              marginBottom: "10px",
              height: 35,
              fontSize: 15,
            }}
            type="text"
            onChange={(e) => {
              setCourseNo(e.target.value);
            }}
            placeholder="Course No."
          ></input>
          <input
            style={{
              marginBottom: "20px",
              height: 35,
              fontSize: 15,
            }}
            type="text"
            onChange={(e) => {
              setCourseTitle(e.target.value);
            }}
            placeholder="Course Title"
          ></input>
          <Button
            variant="contained"
            onClick={handleAdd}
            sx={{ backgroundColor: "#28295C" }}
          >
            Submit
          </Button>
        </div>
      </Dialog>
    </div>
  );
}
