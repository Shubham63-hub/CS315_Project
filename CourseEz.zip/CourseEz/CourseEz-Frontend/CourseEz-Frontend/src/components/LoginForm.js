import React, { useState } from "react";
import Paper from '@mui/material/Paper';
import LockIcon from '@mui/icons-material/Lock';
import { Button } from "@mui/material";
import Logo from "../images/loginLogo.svg"
import axios from "axios";
import { useNavigate } from "react-router-dom";

function LoginForm() {
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();
    const [status, setStatus] = useState();
    const navigate = useNavigate();

    const centerMaking = {
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center'
    }

    const handleSubmit = async (e) => {
        e.preventDefault();

        axios
            .post("http://localhost:8080/login", {
                "emailId": email,
                "password": password
            })
            .then(response => {
                console.log(response);
                if (response.data.status == false) {
                    setStatus(false);
                }
                else {
                    setStatus(true);
                    navigate("/home",
                        {
                            state: {
                                isProf: response.data.isProf,
                                userId: response.data.userId
                            }
                        });
                }
            })

    }

    return (
        <div style={centerMaking}>
            <img src={Logo} style={{ width: "300px" }} />
            <Paper elevation={6} sx={{
                height: 400,
                width: 350,
                borderRadius: 10,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                postion: "relative",
                flexDirection: "column"
            }}>
                <LockIcon sx={{ color: "#28295C" }} />
                {
                    (status == undefined)
                        ? <></>
                        : (status == false)
                            ? <p style={{ color: "red" }}> Username or Password is Incorrect.</p>
                            : <></>
                }
                <h2>Login</h2>
                <input type="text" style={{ marginBottom: 20, outline: "0", borderWidth: "0 0 2px" }} placeholder="Email*"
                    onChange={(e) => { setEmail(e.target.value) }} />
                <input type="password" style={{ marginBottom: 40, outline: "0", borderWidth: "0 0 2px" }} placeholder="Password*"
                    onChange={(e) => { setPassword(e.target.value) }} />
                <Button variant="contained" onClick={handleSubmit} sx={{ backgroundColor: "#28295C" }}>Sign in</Button>
            </Paper>

        </div>
    )
}

export default LoginForm