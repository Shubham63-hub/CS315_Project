import React from 'react'
import { useState, useEffect } from 'react';
import QuizItem from './QuizItem';
import axios from "axios";
import { useLocation, useNavigate } from 'react-router-dom';
import { Button } from '@mui/material'

// const quizzes = [
//   {
//     is_submitted: true,
//     Marks: 24
//   },
//   {
//     is_submitted: false,
//     Marks: 24
//   },
//   {
//     is_submitted: false,
//     Marks: 24
//   },
//   {
//     is_submitted: true,
//     Marks: 49
//   },
//   {
//     is_submitted: false,
//     Marks: 24
//   },

// ];

export default function Quizzes() {
  const [quizzes, setQuizzes] = useState([]);
  const [allmarks, setAllMarks] = useState([]);
  const { state } = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .post("http://localhost:8080/getquizzes", null, {
        params: {
          courseId: state.courseId,
        },
      })
      .then((res) => {
        setQuizzes(res.data);
      });

    if (!state.isProf) {
      axios
        .post("http://localhost:8080/getmarks", null, {
          params: {
            userId: state.userId,
            courseId: state.courseId,
          },
        })
        .then((res) => {
          setAllMarks(res.data);
        });
    }

  });

  const handleSubmit = () => {
    navigate("/addstudents",
      {
        state: {
          userId: state.userId,
          courseId: state.courseId
        }
      });
  }

  const handleAddQuiz = () => {
    navigate("/addquestion",
      {
        state: {
          courseId: state.courseId
        }
      });
  }

  return (
    <div className="Quizzes">
      {state.isProf
        ? (<>
          <Button variant="contained" onClick={handleSubmit} sx={{ backgroundColor: "#28295C", marginRight: '1%', marginTop: '1%', marginBottom: '1%' }}>Add students</Button>
          <Button variant="contained" onClick={handleAddQuiz} sx={{ backgroundColor: "#28295C", marginTop: '1%', marginBottom: '1%' }}>Add Quiz</Button>

        </>)
        : <></>
      }
      {quizzes.map((quiz, index) => (
        <QuizItem
          quizkey={index + 1}
          quizId={quiz.quizId}
          userId={state.userId}
          isSubmitted={allmarks.length == 0
            ? 0
            : allmarks[index].isSubmitted}
          marks={allmarks.length == 0
            ? 0
            : allmarks[index].marks}
          isAttempted={
            allmarks.length == 0
              ? 0
              : allmarks[index].isAttempted}
          isProf={state.isProf}
        />
      ))}
    </div>
  )
}
