import React, { useEffect } from "react";
import { useState } from "react";
// import { Mcq } from "./Mcq";
// import { Num } from "./Num";
import "./QuestionsListProf.css"; // import CSS file,l
import { useLocation } from "react-router-dom";


import axios from "axios";
import { Button, Paper } from "@mui/material";

export const QuestionsListProf = () => {
  const { state } = useLocation();
  const [mcqs, setmcqs] = useState([]);
  const [nums, setnums] = useState([]);

  useEffect(() => {
    axios
      .post("http://localhost:8080/getmcqs", null, {
        params: {
          quizId: state.quizId,
        },
      })
      .then((res) => {
        // console.log(res);
        setmcqs(res.data);
      });

    axios
      .post("http://localhost:8080/getnums", null, {
        params: {
          quizId: state.quizId,
        },
      })
      .then((res) => {
        // console.log(res);
        setnums(res.data);
      });
  }, []);

  return (
    <div>
      <h2>Multiple Choice Questions</h2>
      {mcqs.map((q) => {
        var id = mcqs.findIndex((element) => element === q);
        return (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Paper
              elevation={6}
              sx={{
                width: "90%",
                marginBottom: "25px",
                borderRadius: "15px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: "40px",
              }}
            >
              <div className="mcq-container">
                <div className="mcq-header">
                  <h4>
                    Q{id + 1}) {q.description}
                  </h4>
                </div>
                <div>
                  <div className="mcq-option">
                    <label>A) {q.optA}</label>
                  </div>
                  <div className="mcq-option">
                    <label>B) {q.optB}</label>
                  </div>
                  <div className="mcq-option">
                    <label>C) {q.optC}</label>
                  </div>
                  <div className="mcq-option">
                    <label>D) {q.optD}</label>
                  </div>
                  <br />
                  <div className="mcq-header">
                    <h3>Solution:   {q.solution}</h3>
                  </div>
                </div>
              </div>
            </Paper>
          </div>
        );
      })}
      <h2>Numerical Questions</h2>
      {nums.map((q) => {
        var id = nums.findIndex((element) => element === q);
        return (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Paper
              elevation={6}
              sx={{
                width: "90%",
                marginBottom: "25px",
                borderRadius: "15px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: "40px",
              }}
            >
              <div className="mcq-container">
                <div className="mcq-header">
                  <h4>
                    Q{id + 1}) {q.description}
                  </h4>
                </div>
                <div>
                  <div className="mcq-header">
                    <h3>Solution: {q.solution}</h3>
                  </div>
                </div>
              </div>
            </Paper>
          </div>
        );
      })}
    </div>
  );
};

// export default QuestionsList
