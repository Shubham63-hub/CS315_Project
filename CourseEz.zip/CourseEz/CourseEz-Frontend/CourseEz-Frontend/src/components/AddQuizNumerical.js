import React, { useState } from "react";
import "./Num.css";

export const AddQuizNumerical = (props) => {
  return (
    <div className="num-container">
      <div className="num-header">
        <h4>
          Q{props.id + 1}) {props.description}
        </h4>
      </div>
      <input
        onChange={(e) => e.preventDefault()}
        className="num-input"
        type="number"
        value={props.value}
      />
    </div>
  );
};
