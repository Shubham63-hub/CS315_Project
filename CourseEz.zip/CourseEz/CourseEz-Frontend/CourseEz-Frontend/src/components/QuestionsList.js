import React, { useEffect } from "react";
import { useState } from "react";
import { Mcq } from "./Mcq";
import { Num } from "./Num";
import axios from "axios";
import { Button, Paper } from "@mui/material";
import { useLocation, useNavigate } from "react-router-dom";

export const QuestionsList = () => {
  const { state } = useLocation();
  const [mcqs, setmcqs] = useState([]);
  const [nums, setnums] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    // previous page
    // axios.post("http://localhost:8080/attempted", null, {
    //   params: {
    //     userId: state.userId,
    //     quizId: state.quizId,
    //   },
    // });

    // state.quizId
    axios
      .post("http://localhost:8080/getmcqs", null, {
        params: {
          quizId: state.quizId,
        },
      })
      .then((res) => {
        // console.log(res);
        setmcqs(res.data);
      });

    axios
      .post("http://localhost:8080/getnums", null, {
        params: {
          quizId: state.quizId,
        },
      })
      .then((res) => {
        // console.log(res);
        setnums(res.data);
      });
  }, []);
  var McqMarked = [];
  var NumMarked = [];
  for (var i = 0; i < mcqs.length; i++) {
    McqMarked.push({
      id: i,
      qid: mcqs[i].questionId,
      ans: null,
    });
  }
  for (i = 0; i < nums.length; i++) {
    NumMarked.push({
      id: i,
      qid: nums[i].questionId,
      ans: null,
    });
  }
  const handleMcqChange = (id, marked) => {
    const arr = marked.sort();
    McqMarked[id].ans = arr.join(",");
    // console.log(McqMarked[id].qid,McqMarked[id].ans);
  };
  const handleNumChange = (id, marked) => {
    NumMarked[id].ans = marked;
    // console.log(NumMarked[id].qid, NumMarked[id].ans);
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(McqMarked);
    console.log(NumMarked);
    var marks = 0;
    for (i = 0; i < mcqs.length; i++) {
      if (McqMarked[i].ans != null && McqMarked[i].ans === mcqs[i].solution) {
        marks++;
      }
    }
    for (i = 0; i < nums.length; i++) {
      if (NumMarked[i].ans != null && NumMarked[i].ans === nums[i].solution) {
        marks++;
      }
    }
    console.log(marks);
    // Post data to last table here
    axios.post("http://localhost:8080/submitted", null, {
      params: {
        quizId: state.quizId,
        userId: state.userId,
        marks: marks,
      },
    }).then(
      (res) =>{
        navigate(-1);
      }
    );
  };

  return (
    <div>
      <h2>Multiple Choice Questions</h2>
      {mcqs.map((q) => {
        var id = mcqs.findIndex((element) => element === q);
        return (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Paper
              elevation={6}
              sx={{
                width: "90%",
                marginBottom: "25px",
                borderRadius: "15px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: "40px",
              }}
            >
              <Mcq
                description={q.description}
                optionA={q.optA}
                optionB={q.optB}
                optionC={q.optC}
                optionD={q.optD}
                id={id}
                // marked={McqMarked[id].ans}
                onChange={handleMcqChange}
              />
            </Paper>
          </div>
        );
      })}
      <h2>Numerical Questions</h2>
      {nums.map((q) => {
        var id = nums.findIndex((element) => element === q);
        return (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Paper
              elevation={6}
              sx={{
                width: "90%",
                marginBottom: "25px",
                borderRadius: "15px",
                marginBottom: "40px",
              }}
            >
              <Num
                description={q.description}
                id={id}
                onChange={handleNumChange}
              />
            </Paper>
          </div>
        );
      })}

      <Button
        size="large"
        variant="contained"
        onClick={handleSubmit}
        sx={{ backgroundColor: "#28295C", marginBottom: "50px" }}
      >
        Submit
      </Button>
    </div>
  );
};

// export default QuestionsList