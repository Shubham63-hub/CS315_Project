// import React from 'react'
// import { useState } from 'react'
// export const  Mcq = () => {
//   let description = "MCQ Question description";
//   let option1 = "1";
//   let option2 = "2";
//   let option3 = "3";
//   let option4 = "4";
//   const [marked,setMarked] = useState([]);
//   const handleChange = (e) => {
//     const value = e.target.value;
//     const checked = e.target.checked;
//     if(checked) {
//         setMarked([
//             ...marked,value
//         ])
//     }
//     else{
//         setMarked(marked.filter( (e) => (e!==value)));
//     }
//   }
//   return (
//     <div>
//       <form>
//         <div
//           style={{
//             display: "flex",
//             alignItems: "center",
//             justifyContent: "center",
//           }}
//         >
//           <h4>{description}</h4>
//         </div>
//         <div>
//           <input onChange={handleChange} type="checkbox" value={1} />
//           <label>{option1}</label>
//         </div>
//         <div>
//           <input onChange={handleChange} type="checkbox" value={2} />
//           <label>{option2}</label>
//         </div>
//         <div>
//           <input onChange={handleChange} type="checkbox" value={3} />
//           <label>{option3}</label>
//         </div>
//         <div>
//           <input onChange={handleChange} type="checkbox" value={4} />
//           <label>{option4}</label>
//         </div>
//       </form>
//     </div>
//   );
// }

import React from "react";
import "./Mcq.css"; // import CSS file

export const Mcq = (props) => {
  // let description = "MCQ Question description";
  // let option1 = "1";
  // let option2 = "2";
  // let option3 = "3";
  // let option4 = "4";
  let marked = [];
  const handleChange = (e) => {
    const value = e.target.value;
    const checked = e.target.checked;
    console.log(checked);
    if (checked) {
      console.log("else1");
      marked.push(value);
      // marked = [...marked, value];
      console.log(marked);
    } else {
      console.log("else");
      marked = marked.filter((e) => e !== value);
      console.log(marked);
    }
    // console.log(marked);
    props.onChange(props.id, marked);
  };
  return (
    <div className="mcq-container">
      <div className="mcq-header">
        <h4>
          Q{props.id + 1}) {props.description}
        </h4>
      </div>
      <form>
        <div className="mcq-option">
          <input onChange={handleChange} type="checkbox" value={"A"} />
          <label>{props.optionA}</label>
        </div>
        <div className="mcq-option">
          <input onChange={handleChange} type="checkbox" value={"B"} />
          <label>{props.optionB}</label>
        </div>
        <div className="mcq-option">
          <input onChange={handleChange} type="checkbox" value={"C"} />
          <label>{props.optionC}</label>
        </div>
        <div className="mcq-option">
          <input onChange={handleChange} type="checkbox" value={"D"} />
          <label>{props.optionD}</label>
        </div>
      </form>
    </div>
  );
};
