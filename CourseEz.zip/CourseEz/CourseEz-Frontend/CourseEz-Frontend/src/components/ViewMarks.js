import { Button, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom';

function ViewMarks() {
    const { state } = useLocation();
    const [allStudents, setAllStudents] = useState([]);
    
    useEffect(() => {
        axios
            .post("http://localhost:8080/viewmarks", null, {
                params:
                {
                    // courseId: state.courseId,
                    quizId: state.quizId
                }
            })
            .then((res) => {
                // console.log(res.data);
                setAllStudents(res.data);
            })
    });

    return (
        <div style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center"

        }}>

       
        <TableContainer style={{marginTop: "30px", width: "90%"}} component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
                <TableHead>
                    <TableRow style={{backgroundColor: "#28295C"}}>
                        <TableCell style={{fontSize: "18px", color:"white"}}>Roll No.</TableCell>
                        <TableCell style={{fontSize: "18px", color:"white"}} align="right">Name</TableCell>
                        <TableCell style={{fontSize: "18px", color:"white"}} align="right">Marks</TableCell>
                        {/* <TableCell style={{fontSize: "18px", color:"white"}} align="right">Add</TableCell> */}
                    </TableRow>
                </TableHead>
                <TableBody>
                    {allStudents.map((row) => (
                        <TableRow
                            key={row.rollNo}
                            sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                        >
                            <TableCell style={{fontSize: "16px"}} component="th" scope="row">
                                {row.rollNo}
                            </TableCell>
                            <TableCell style={{fontSize: "16px"}} align="right">{row.name}</TableCell>
                            <TableCell style={{fontSize: "16px"}} align="right">{row.marks}</TableCell>
                            {/* <TableCell style={{fontSize: "16px"}} align="right">
                                <Button variant="contained"
                                    onClick={() => {
                                        console.log(row.userId + " " + state.courseId);
                                        axios
                                            .post("http://localhost:8080/addstudent", null, {
                                                params:
                                                {
                                                    userId: row.userId,
                                                    courseId: state.courseId
                                                }
                                            })
                                            .then((res) => console.log(res));
                                    }}
                                    sx={{ backgroundColor: "#28295C" }}>
                                    Add
                                </Button>
                            </TableCell> */}
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer >
        </div>
    )
}

export default ViewMarks
