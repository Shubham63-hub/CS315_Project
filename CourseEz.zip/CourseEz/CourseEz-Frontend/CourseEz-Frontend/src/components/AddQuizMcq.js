import React from "react";
import "./Mcq.css"; // import CSS file

export const AddQuizMcq = (props) => {
  let marked = props.marked;

  return (
    <div className="mcq-container">
      <div className="mcq-header">
        <h4>
          Q{props.id + 1}) {props.description}
        </h4>
      </div>
      <form>
        <div className="mcq-option">
          <input onClick={(e) => e.preventDefault()} checked={marked.find((e) => e === 'A')} type="checkbox" value={"A"} />
          <label>{props.optionA}</label>
        </div>
        <div className="mcq-option">
          <input onClick={(e) => e.preventDefault()} checked={marked.find((e) => e === 'B')} type="checkbox" value={"B"} />
          <label>{props.optionB}</label>
        </div>
        <div className="mcq-option">
          <input onClick={(e) => e.preventDefault()} checked={marked.find((e) => e === 'C')} type="checkbox" value={"C"} />
          <label>{props.optionC}</label>
        </div>
        <div className="mcq-option">
          <input onClick={(e) => e.preventDefault()} checked={marked.find((e) => e === 'D')} type="checkbox" value={"D"} />
          <label>{props.optionD}</label>
        </div>
      </form>
    </div>
  );
};
