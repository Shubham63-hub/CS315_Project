import React, { useState } from 'react'
import Dialog from "@mui/material/Dialog";
import { useLocation, useNavigate } from "react-router-dom";
import { Button, Paper } from "@mui/material";
import { AddQuizMcq } from "./AddQuizMcq";
import { AddQuizNumerical } from "./AddQuizNumerical";
import { Num } from "./Num";
import axios from 'axios';

const AddQuiz = () => {
    const { state } = useLocation()
    const [qtype, setQtype] = useState("MCQ")
    const [open, setOpen] = useState(false)
    const [questionDesc, setQuestionDesc] = useState(" ");
    const [opt1, setOpt1] = useState("");
    const [opt2, setOpt2] = useState("");
    const [opt3, setOpt3] = useState("");
    const [opt4, setOpt4] = useState("");
    const [mcqAns, setMcqAns] = useState([]);
    const [numAns, setNumAns] = useState(null);
    const [mcqList, setMcqList] = useState([]);
    const [numList, setNumList] = useState([]);
    const navigate = useNavigate();

    console.log(state)


    const handleMCQChange = (e) => {
        const checked = e.target.checked
        const value = e.target.value
        let mcqAns2 = mcqAns
        if (checked) {
            mcqAns2.push(value)
        } else {
            mcqAns2 = mcqAns2.filter((x) => x !== value);
        }

        console.log(mcqAns2)
        setMcqAns(mcqAns2)
    }

    const handleQuizSubmit = () => {
        axios
            .post("http://localhost:8080/addquiz", {
                "courseId": state.courseId,
                "mcqQuestions": mcqList,
                "numQuestions": numList
            })
            .then((res) => {
                navigate(-1);
            });
    }

    const handleMcqQuestionSubmit = () => {
        let obj = {
            description: questionDesc,
            optA: opt1,
            optB: opt2,
            optC: opt3,
            optD: opt4,
            solution: mcqAns.sort().join(",")
        }

        let mcqList2 = mcqList
        mcqList2.push(obj)
        console.log(mcqList2)
        setMcqList(mcqList2)
        
        setQuestionDesc("");
        setOpt1("")
        setOpt2("")
        setOpt3("")
        setOpt4("")
        setMcqAns([])
        document.querySelectorAll("input[type=checkbox]").forEach((it) => { it.checked = false })
    }

    const handleNumericalQuestionSubmit = () => {
        let obj = {
            description: questionDesc,
            solution: numAns
        }

        let numList2 = numList
        numList2.push(obj)
        console.log(numList2)
        setNumList(numList2)

        setQuestionDesc("")
        setNumAns(0)
        document.querySelector("input[type=number]").value = 0
    }

    return (
        <div style={{ marginTop: '20px' }}>
            <div style={{
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'center'
            }}>
                <div style={{ margin: 2 }}>
                    <input type="radio" name="qType" value="MCQ" onChange={(e) => { setQtype(e.target.value) }} />
                    <label style={{ fontSize: '1.2em' }} htmlFor='qType'>MCQ</label>
                    <input style={{ marginLeft: 18 }} type="radio" name="qType" value="FillUp" onChange={(e) => { setQtype(e.target.value) }} />
                    <label style={{ fontSize: '1.2em' }} htmlFor='qType'>Numerical</label>
                </div>

                <div style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'center',
                    alignItems: 'center'
                }}>
                    <Button
                        variant="contained"
                        onClick={() => { setOpen(true) }}
                        sx={{ backgroundColor: "#28295C", margin: 2 }}
                    >
                        Add Question
                    </Button>
                    <Button
                        variant="contained"
                        onClick={handleQuizSubmit}
                        sx={{ backgroundColor: "#28295C" }}
                    >
                        Submit Quiz
                    </Button>
                </div>
            </div>

            {qtype === "MCQ" ?
                <Dialog
                    open={open}
                    onClose={() => {
                        setOpen(false);
                    }}
                    style={{
                        borderRadius: 10,
                    }}
                >
                    <div style={{
                        padding: 20,
                        borderRadius: "300px",
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        justifyContent: "center",
                    }}>
                        <label htmlFor='ques'>Question</label>
                        <input style={{ width: 400, height: 70 }} type="text" value={questionDesc} onChange={(e) => { setQuestionDesc(e.target.value) }} name="ques1" /> <br />
                        <label htmlFor='op1'>Option A</label>
                        <input style={{ width: 400, height: 40 }} type="text" value={opt1} onChange={(e) => { setOpt1(e.target.value) }} name="op1" /><br />
                        <label htmlFor='op2'>Option B</label>
                        <input style={{ width: 400, height: 40 }} type="text" value={opt2} onChange={(e) => { setOpt2(e.target.value) }} name="op2" /><br />
                        <label htmlFor='op3'>Option C</label>
                        <input style={{ width: 400, height: 40 }} type="text" value={opt3} onChange={(e) => { setOpt3(e.target.value) }} name="op3" /><br />
                        <label htmlFor='op4'>Option D</label>
                        <input style={{ width: 400, height: 40 }} type="text" value={opt4} onChange={(e) => { setOpt4(e.target.value) }} name="op4" /><br />
                        <div style={{
                            display: 'flex',
                            flexDirection: 'row',
                            justifyContent: 'center',
                            alignItems: 'center'
                        }}>
                            <input type="checkbox" onChange={handleMCQChange} name="option1" value="A" />
                            <label htmlFor="option1">A</label>
                            <input type="checkbox" onChange={handleMCQChange} name="option2" value="B" />
                            <label htmlFor="option2">B</label>
                            <input type="checkbox" onChange={handleMCQChange} name="option3" value="C" />
                            <label htmlFor="option3">C</label>
                            <input type="checkbox" onChange={handleMCQChange} name="option4" value="D" />
                            <label htmlFor="option4">D</label> <br />
                        </div>

                        <Button
                            variant="contained"
                            onClick={handleMcqQuestionSubmit}
                            sx={{ backgroundColor: "#28295C", marginTop: 2 }}
                        >
                            Submit
                        </Button>

                    </div>
                </Dialog>
                :
                <Dialog
                    open={open}
                    onClose={() => {
                        setOpen(false);
                    }}
                    style={{
                        borderRadius: 10,
                    }}
                >
                    <div style={{
                        padding: 20,
                        borderRadius: "300px",
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        justifyContent: "center",
                    }}>
                        <label htmlFor="ques2">Question</label>
                        <input style={{ width: 400, height: 100 }} value={questionDesc} type="text" onChange={(e) => { setQuestionDesc(e.target.value) }} name="ques2" /><br />
                        <label htmlFor="ans">Answer</label>
                        <input style={{ width: 400, height: 20 }} value={numAns} type="number" onChange={(e) => { setNumAns(parseFloat(e.target.value)) }} name="ans" />
                        <br />
                        <Button
                            variant="contained"
                            onClick={handleNumericalQuestionSubmit}
                            sx={{ backgroundColor: "#28295C", marginTop: 0.7 }}
                        >
                            Submit
                        </Button>
                    </div>
                </Dialog>
            }

            {/* -------------- Question Display -------------------- */}
            <div>
                <h2>Multiple Choice Questions</h2>
                {mcqList.map((q, id) => {
                    return (
                        <div
                            style={{
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                            }}
                        >
                            <Paper
                                elevation={6}
                                sx={{
                                    width: "90%",
                                    marginBottom: "25px",
                                    borderRadius: "15px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    marginBottom: "40px",
                                }}
                            >
                                <AddQuizMcq
                                    description={q.description}
                                    optionA={q.optA}
                                    optionB={q.optB}
                                    optionC={q.optC}
                                    optionD={q.optD}
                                    id={id}
                                    marked={q.solution.split(',')}
                                />
                            </Paper>
                        </div>
                    );
                })}

                <h2>Numerical Questions</h2>
                {numList.map((q, id) => {
                    return (
                        <div
                            style={{
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                            }}
                        >
                            <Paper
                                elevation={6}
                                sx={{
                                    width: "90%",
                                    marginBottom: "25px",
                                    borderRadius: "15px",
                                    marginBottom: "40px",
                                }}
                            >
                                <AddQuizNumerical
                                    description={q.description}
                                    id={id}
                                    value={q.solution}
                                />
                            </Paper>
                        </div>
                    );
                })}
            </div>
        </div>
    )
}

export default AddQuiz