import React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';

export default function ButtonAppBar(props) {
    return (
        <Box sx={{ flexGrow: 1, flexDirection: "left" }}>
            <AppBar position="static">
                <Toolbar sx={{backgroundColor: "#28295C"}}>
                    <Typography variant="h6" component="div" >
                        {props.courseName}
                    </Typography>
                </Toolbar>
            </AppBar>
        </Box>
    );
}