
import React, { useState } from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function QuizItem(props) {

  const [status, setStatus] = useState();
  const navigate = useNavigate();

  const attemptQuiz = async (e) => {
    axios
      .post("http://localhost:8080/attemptQuiz", null, {
        params: {
          quizId: props.quizId,
          userId: props.userId
        }
      }
      )
      .then(() => {
        navigate("/quiz",//url for attempting quiz
          {
            state: {
              userId: props.userId,
              quizId: props.quizId,

              isProf: 0
            }
          });

      })

  }

  const handleMarks = () => {
    navigate("/viewmarks",//url for attempting quiz
      {
        state: {
          courseId: props.courseId,
          quizId: props.quizId
        }
      });
  }

  return (
    <Box sx={{ flexGrow: 1, marginBottom: '10px' }}>
      <AppBar position="static" sx={{ bgcolor: "white", borderRadius: '10px' }}>
        <Toolbar>
          <Typography
            variant="h6"
            component="div"
            sx={{
              flexGrow: 1,
              color: "Black",
            }}>
            {"Quiz " + props.quizkey}
          </Typography>
          {props.isProf
            ? (
              <>
                <Button
                  sx={{
                    bgcolor: '#28295C',
                    ":hover": { backgroundColor: '#252533' },
                    marginRight: '1%'
                  }}
                  variant='contained'
                  onClick={() => {
                    navigate("/quizProf",//url for attempting quiz
                      {
                        state: {
                          userId: props.userId,
                          quizId: props.quizId
                        }
                      });
                  }}>
                  View Quiz
                </Button>
                <Button
                  sx={{
                    bgcolor: '#28295C',
                    ":hover": { backgroundColor: '#252533' }
                  }}
                  variant='contained'
                  onClick={handleMarks}>
                  View Marks
                </Button>
              </>

            )
            : (
              <>
                {!props.isAttempted ? (
                  <Button
                    sx={{
                      bgcolor: '#28295C',
                      ":hover": { backgroundColor: '#252533' }
                    }}
                    variant='contained'
                    onClick={attemptQuiz}>
                    Take Quiz
                  </Button>
                ) : (
                  <Button
                    color='success'
                    variant='outlined'>
                    {"Marks: " + props.marks}
                  </Button>
                )}
              </>
            )}





        </Toolbar>
      </AppBar>
    </Box>
  );
}