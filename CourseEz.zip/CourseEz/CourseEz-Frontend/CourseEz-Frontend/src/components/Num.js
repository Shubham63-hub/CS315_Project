// import React from 'react'
// import { useState } from "react";

// export const Num = () => {
//   let description = "Numeric Question description";
//    const [value, setValue] = useState(0);
//     const handleChange = (event) => {
//       const newValue = event.target.value;
//       setValue(newValue);
//     };
//   return (
//     <div>
//       <div
//         style={{
//           display: "flex",
//           alignItems: "center",
//           justifyContent: "center",
//         }}
//       >
//         <h3>{description}</h3>
//       </div>
//       <input type="number" value={value} onChange={handleChange} />
//     </div>
//   );
// }
import React, { useState } from "react";
import "./Num.css"; // import CSS file

export const Num = (props) => {
  // let description = "Numeric Question description";
  // const floatRegExp = new RegExp("^([-]?([0-9]+([.][0-9]*)?|[.][0-9]+)$");
  // const floatRegExp = /^[-]?\d*\.?\d+$/;
  const [value, setValue] = useState("");
  // const handleChange = (event) => {
  //  const newValue = event.target.value;
  //  if (newValue === "" || floatRegExp.test(newValue)) {
  //    setValue(newValue);
  //  }
  const handleChange = (event) => {
    const newValue = event.target.value;
    setValue(newValue);
    props.onChange(props.id,parseFloat(newValue))
  };
  // };
  return (
    <div className="num-container">
      <div className="num-header">
        <h4>
          Q{props.id + 1}) {props.description}
        </h4>
      </div>
      <input
        className="num-input"
        type="number"
        value={value}
        onChange={handleChange}
      />
    </div>
  );
};
