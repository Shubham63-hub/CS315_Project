import { Button } from '@mui/material'
import React from 'react'
import { useLocation, useNavigate } from 'react-router-dom';

function Course() {
  const navigate = useNavigate();
  const { state } = useLocation();
  // console.log(state.userId);
  const handleSubmit = () => {
    navigate("/addstudents",
      {
        state: {
          userId: state.userId,
          courseId: state.courseId
        }
      });
  }
  return (
    <div>
      {state.isProf
       ? (<Button variant="contained" onClick={handleSubmit} sx={{ backgroundColor: "#28295C" }}>Add students</Button>)
      : <></> 
      }
      
    </div>
  )
}

export default Course
