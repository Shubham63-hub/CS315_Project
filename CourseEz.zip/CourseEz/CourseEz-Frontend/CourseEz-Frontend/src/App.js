import './App.css';
import Login from './views/Login';
import { QuestionsList } from "./components/QuestionsList";
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom"
import StudentUser from './views/StudentUser';
import Addstudents from './views/Addstudents'
import QuizzesList from './views/QuizzesList';
import QuestionListProf from './views/QuestionListProf';
import ViewMarks from './components/ViewMarks';
import AddQuizPage from './views/AddQuizPage';

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route exact path="/" element={<Login/>} />
          <Route exact path="/home" element={<StudentUser/>} />
          <Route exact path="/quiz" element={<QuestionsList />} />
          <Route exact path="/coursepage" element={<QuizzesList />} />
          <Route exact path="/addstudents" element={<Addstudents />} />
          <Route exact path="/quizProf" element={<QuestionListProf/>} />
          <Route exact path="/viewmarks" element={<ViewMarks/>} />
          <Route exact path="/addquestion" element={<AddQuizPage/>} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
