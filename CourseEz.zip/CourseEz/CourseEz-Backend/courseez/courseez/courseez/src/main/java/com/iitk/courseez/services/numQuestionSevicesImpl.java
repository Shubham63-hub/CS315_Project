package com.iitk.courseez.services;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iitk.courseez.dao.numQuestionDao;
import com.iitk.courseez.dao.quizQuestionidDao;
import com.iitk.courseez.model.quizQuestionid;
import com.iitk.courseez.model.numQuestion;


@Service
public class numQuestionSevicesImpl implements numQuestionServices {
    @Autowired
    quizQuestionidDao quizQuestionidDao;

    @Autowired
    numQuestionDao numQuestionDao;

    @Override
    public List<numQuestion> GetAllNumQuestions(int quizId) {
        List<quizQuestionid> quizQuestions = quizQuestionidDao.findByQuizId(quizId);
        List<numQuestion> numQuestions = new ArrayList<numQuestion>();
        int isMcq; int questionId;
        for( int i=0 ; i<quizQuestions.size() ; i++) {
            questionId = quizQuestions.get(i).getQuestionId();
            isMcq = quizQuestions.get(i).getIsMcq();
            if(isMcq == 0) {
                numQuestions.add(numQuestionDao.findByQuestionId(questionId));
            }
        }
        return numQuestions;
    }

}
