package com.iitk.courseez.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iitk.courseez.model.mcqQuestion;

@Repository
public interface mcqQuestionDao extends JpaRepository<mcqQuestion, Integer>  {
    public mcqQuestion findByQuestionId(int questionId);
    
}
