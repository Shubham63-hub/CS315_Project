package com.iitk.courseez.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.iitk.courseez.dao.quizMarksDao;
import com.iitk.courseez.dao.userDao;
import com.iitk.courseez.model.quizMarks;
import com.iitk.courseez.model.user;

@RestController
public class viewMarksController {
    @Autowired
    quizMarksDao quizMarksDao;

    @Autowired
    userDao userDao;

    ObjectMapper mapper = new ObjectMapper();

    @PostMapping("/viewmarks")
    @CrossOrigin
    public  List<ObjectNode> viewMarks(@RequestParam Integer quizId){
        List<ObjectNode> finalObject = new ArrayList<ObjectNode>();
        List<quizMarks> allMarks = new ArrayList<quizMarks>();
        allMarks = quizMarksDao.findByQuizId(quizId);
        for(int i = 0 ;  i < allMarks.size(); i++){
            int marks = allMarks.get(i).getMarks();
            user user = userDao.findByUserId(allMarks.get(i).getUserId());
            ObjectNode o = mapper.createObjectNode();
            o.set("rollNo", mapper.convertValue(user.getRollNo(), JsonNode.class) );
            o.set("name", mapper.convertValue(user.getName(), JsonNode.class));
            o.set("marks", mapper.convertValue(marks, JsonNode.class));
            finalObject.add(o);
        }
        return finalObject;
    }
}
