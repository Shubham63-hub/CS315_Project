package com.iitk.courseez.services;

import com.iitk.courseez.model.loginInfo;

public interface loginInfoServices {
    public abstract loginInfo GetLoginInfo(String emailId);
}
