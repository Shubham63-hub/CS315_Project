package com.iitk.courseez.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class mcqQuestion {
    public mcqQuestion() {}

    @Id
    @GeneratedValue
    private int questionId;
    
    private String description;
    private String solution;
    private String optA;
    private String optB;
    private String optC;
    private String optD;
    // public mcqQuestion(String description, String solution, String optA, String optB, String optC, String optD) {
    //     this.description = description;
    //     this.solution = solution;
    //     this.optA = optA;
    //     this.optB = optB;
    //     this.optC = optC;
    //     this.optD = optD;
    // }
    public int getQuestionId() {
        return questionId;
    }
    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }
    public String getdescription() {
        return description;
    }
    public void setdescription(String description) {
        this.description = description;
    }
    public String getsolution() {
        return solution;
    }
    public void setsolution(String solution) {
        this.solution = solution;
    }
    public String getOptA() {
        return optA;
    }
    public void setOptA(String optA) {
        this.optA = optA;
    }
    public String getOptB() {
        return optB;
    }
    public void setOptB(String optB) {
        this.optB = optB;
    }
    public String getOptC() {
        return optC;
    }
    public void setOptC(String optC) {
        this.optC = optC;
    }
    public String getOptD() {
        return optD;
    }
    public void setOptD(String optD) {
        this.optD = optD;
    }
  

}
