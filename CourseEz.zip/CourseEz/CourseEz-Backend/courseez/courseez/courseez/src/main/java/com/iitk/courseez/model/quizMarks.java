package com.iitk.courseez.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class quizMarks {
    public quizMarks() {}

    @Id
    @GeneratedValue
    private int id;

    private int userId;
    private int quizId;
    private int marks;
    private int isSubmitted;
    private int isAttempted;
    public int getIsSubmitted() {
        return isSubmitted;
    }
    public void setIsSubmitted(int isSubmitted) {
        this.isSubmitted = isSubmitted;
    }
    public int getIsAttempted() {
        return isAttempted;
    }
    public void setIsAttempted(int isAttempted) {
        this.isAttempted = isAttempted;
    }
    

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public int getQuizId() {
        return quizId;
    }

    public quizMarks(int userId, int quizId, int marks, int isSubmitted, int isAttempted) {
        this.userId = userId;
        this.quizId = quizId;
        this.marks = marks;
        this.isSubmitted = isSubmitted;
        this.isAttempted = isAttempted;
    }
    public void setQuizId(int quizId) {
        this.quizId = quizId;
    }

    public int getMarks() {
        return marks;
    }
    public void setMarks(int marks) {
        this.marks = marks;
    }
 

}
