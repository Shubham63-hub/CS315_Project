package com.iitk.courseez.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iitk.courseez.dao.userDao;
import com.iitk.courseez.model.user;

@Service
public class userServicesImpl implements userServices {
    @Autowired
    userDao userDao;

    @Override
    public user GetUserInfo(Integer userId){
        return userDao.findByUserId(userId);
    }
}

