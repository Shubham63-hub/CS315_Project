package com.iitk.courseez.services;
import java.util.List;

import com.iitk.courseez.model.mcqQuestion;


public interface mcqQuestionServices {
    public abstract List<mcqQuestion> GetAllMcqQuestions(int quizId);
}
