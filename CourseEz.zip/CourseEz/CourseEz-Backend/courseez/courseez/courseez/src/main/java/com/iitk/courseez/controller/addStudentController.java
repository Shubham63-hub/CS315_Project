package com.iitk.courseez.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.iitk.courseez.dao.userCourseDao;
import com.iitk.courseez.dao.userDao;
import com.iitk.courseez.model.user;
import com.iitk.courseez.model.userCourse;

@RestController
public class addStudentController {
    @Autowired
    userDao userDao;

    @Autowired
    userCourseDao userCourseDao;
    
    @PostMapping("/getstudents")
    @CrossOrigin
    public List<user> getNums(@RequestParam Integer courseId, @RequestParam Integer profId) {
        List<user> finalAns = new ArrayList<user>();
        List<user> temp = new ArrayList<user>();
        temp = userDao.findAll();
        for(int i = 0 ; i < temp.size(); i++){
            if(temp.get(i).getUserId() != profId){
                if(userCourseDao.findByUserIdAndCourseId(temp.get(i).getUserId(), courseId) == null)
                    finalAns.add(temp.get(i));
            }
        }
        return finalAns;
    }

    @PostMapping("/addstudent")
    @CrossOrigin
    public boolean addStudent(@RequestParam Integer userId, @RequestParam Integer courseId){
        userCourse userCourse = userCourseDao.findByUserIdAndCourseId(userId, courseId);
        if(userCourse == null){
            userCourseDao.save(new userCourse(userId, courseId));
            return true;
        }
        return false;
    }
}
