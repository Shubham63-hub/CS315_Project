package com.iitk.courseez.model;

import java.util.List;

public class addQuizBody {
    public Integer courseId;
    public List<mcqQuestion> mcqQuestions;
    public List<numQuestion> numQuestions;

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public List<mcqQuestion> getMcqQuestions() {
        return mcqQuestions;
    }

    public void setMcqQuestions(List<mcqQuestion> mcqQuestions) {
        this.mcqQuestions = mcqQuestions;
    }

    public List<numQuestion> getNumQuestions() {
        return numQuestions;
    }

    public void setNumQuestions(List<numQuestion> numQuestions) {
        this.numQuestions = numQuestions;
    }

    public addQuizBody() {}

    public addQuizBody(Integer courseId, List<mcqQuestion> mcqQuestions, List<numQuestion> numQuestions) {
        this.courseId = courseId;
        this.mcqQuestions = mcqQuestions;
        this.numQuestions = numQuestions;
    }
}
