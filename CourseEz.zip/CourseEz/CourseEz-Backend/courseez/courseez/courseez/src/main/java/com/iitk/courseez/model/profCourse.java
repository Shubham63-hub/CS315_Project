package com.iitk.courseez.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class profCourse {
    public profCourse() {}

    @Id
    @GeneratedValue
    private int id;

    private int userId;
    private int courseId;
    
    public profCourse(int userId, int courseId) {
        this.userId = userId;
        this.courseId = courseId;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public int getCourseId() {
        return courseId;
    }
    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }
   
}
