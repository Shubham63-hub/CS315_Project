package com.iitk.courseez.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class loginInfo {
    public loginInfo(){}

    @Id
    private Integer id;

    private String emailId;
    private String password;
    private Integer isProf;

    
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getEmailId() {
        return emailId;
    }
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public Integer getIsProf() {
        return isProf;
    }
    public void setIsProf(Integer isProf) {
        this.isProf = isProf;
    }

    public loginInfo(Integer id, String emailId, String password, Integer isProf) {
        this.id = id;
        this.emailId = emailId;
        this.password = password;
        this.isProf = isProf;
    }

}
