package com.iitk.courseez.services;

import com.iitk.courseez.model.user;

public interface userServices {
    public abstract user GetUserInfo(Integer userId);
}
