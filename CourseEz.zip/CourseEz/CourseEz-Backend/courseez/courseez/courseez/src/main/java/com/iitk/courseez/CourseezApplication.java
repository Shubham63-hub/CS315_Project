package com.iitk.courseez;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseezApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseezApplication.class, args);
	}

}
