package com.iitk.courseez.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iitk.courseez.model.quizCourse;

@Repository
public interface quizCourseDao extends JpaRepository<quizCourse, Integer>{
    List<quizCourse> findByCourseId(int courseId);
}
