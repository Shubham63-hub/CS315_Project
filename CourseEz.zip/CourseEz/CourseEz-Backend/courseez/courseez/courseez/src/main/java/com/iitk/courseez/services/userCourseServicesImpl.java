package com.iitk.courseez.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iitk.courseez.dao.courseDao;
import com.iitk.courseez.dao.userCourseDao;
import com.iitk.courseez.model.course;
import com.iitk.courseez.model.userCourse;

@Service
public class userCourseServicesImpl implements userCourseServices {
    @Autowired
    userCourseDao userCourseDao;

    @Autowired
    courseDao courseDao;

    @Override
    public List<course> GetAllCourses(int userId) {
        List<userCourse> mapping = userCourseDao.findByUserId(userId);
        List<course> allCourses = new ArrayList<course>();
        for(int i = 0 ; i < mapping.size(); i++){
            int courseId = mapping.get(i).getCourseId();
            allCourses.add(courseDao.findByCourseId(courseId));
        }
        return allCourses;
    }
}
