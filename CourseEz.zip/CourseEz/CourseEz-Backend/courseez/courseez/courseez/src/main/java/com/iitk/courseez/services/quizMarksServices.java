package com.iitk.courseez.services;


public interface quizMarksServices {
    public abstract int getQuizRecordIndex(int userId, int quizId);
    public abstract void updateMarks(int userId, int quizId, int marks);
}
