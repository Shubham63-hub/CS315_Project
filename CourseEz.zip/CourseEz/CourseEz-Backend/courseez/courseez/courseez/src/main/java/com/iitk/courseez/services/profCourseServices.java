package com.iitk.courseez.services;

import com.iitk.courseez.model.user;

public interface profCourseServices {
    public abstract user GetProfFromCourseId(int courseId);
}
