package com.iitk.courseez.services;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iitk.courseez.dao.mcqQuestionDao;
import com.iitk.courseez.dao.quizQuestionidDao;
import com.iitk.courseez.model.quizQuestionid;
import com.iitk.courseez.model.mcqQuestion;


@Service
public class mcqQuestionServicesImpl implements mcqQuestionServices {
    @Autowired
    quizQuestionidDao quizQuestionidDao;

    @Autowired
    mcqQuestionDao mcqQuestionDao;

    @Override
    public List<mcqQuestion> GetAllMcqQuestions(int quizId) {
        List<quizQuestionid> quizQuestions = quizQuestionidDao.findByQuizId(quizId);
        List<mcqQuestion> mcqQuestions = new ArrayList<mcqQuestion>();
        int isMcq; int questionId;
        for( int i=0 ; i<quizQuestions.size() ; i++) {
            questionId = quizQuestions.get(i).getQuestionId();
            isMcq = quizQuestions.get(i).getIsMcq();
            if(isMcq == 1) {
                mcqQuestions.add(mcqQuestionDao.findByQuestionId(questionId));
            }
        }
        return mcqQuestions;
    }

}
