package com.iitk.courseez.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.iitk.courseez.dao.courseDao;
import com.iitk.courseez.dao.profCourseDao;
import com.iitk.courseez.dao.userCourseDao;
import com.iitk.courseez.model.course;
import com.iitk.courseez.model.profCourse;
import com.iitk.courseez.model.user;
import com.iitk.courseez.model.userCourse;
import com.iitk.courseez.services.profCourseServices;
import com.iitk.courseez.services.userCourseServices;
import com.iitk.courseez.services.userServices;

@RestController
public class userHomeController {
    @Autowired
    ObjectMapper mapper;

    @Autowired
    userServices userServices;

    @Autowired
    userCourseServices userCourseServices;

    @Autowired
    profCourseServices profCourseServices;

    @Autowired
    courseDao courseDao;

    @Autowired
    profCourseDao profCourseDao;

    @Autowired
    userCourseDao userCourseDao;
    
    @PostMapping("/userinfo")
    @CrossOrigin
    public ObjectNode getUserInfo(@RequestParam Integer userId){
        user user = userServices.GetUserInfo(userId);
        ObjectNode returnJson = mapper.createObjectNode();
        returnJson.put("name", user.getName());
        returnJson.put("dept", user.getDept());
        returnJson.put("programme", user.getProgramme());
        returnJson.put("rollno", user.getRollNo());

        return returnJson;
    }

    @PostMapping("/getcourses")
    @CrossOrigin
    public List<course> getAllCourses(@RequestParam Integer userId){
        List<course> allCourses = new ArrayList<course>();
        allCourses = userCourseServices.GetAllCourses(userId);
        return allCourses;
    }

    @PostMapping("/getprofs")
    @CrossOrigin
    public List<String> getAllProfs(@RequestBody List<course> allCourses) {
        List<String> allProfs = new ArrayList<String>();
        for(int i = 0 ; i < allCourses.size(); i++) {
            allProfs.add(profCourseServices.GetProfFromCourseId(allCourses.get(i).getCourseId()).getName());
        }
        return allProfs;
    }

    @PostMapping("/addcourse")
    @CrossOrigin
    public Boolean addCourse(@RequestParam Integer profId, @RequestParam String courseNo, @RequestParam String courseTitle) {
        course course = courseDao.findByCourseNo(courseNo);
        if(!(course == null)) {
            return false;
        }

        course newCourse = courseDao.save(new course(courseNo, courseTitle));
        profCourseDao.save(new profCourse(profId, newCourse.getCourseId()));
        userCourseDao.save(new userCourse(profId, newCourse.getCourseId()));

        return true;
    }
}
