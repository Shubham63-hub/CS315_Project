package com.iitk.courseez.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iitk.courseez.dao.profCourseDao;
import com.iitk.courseez.dao.userDao;
import com.iitk.courseez.model.profCourse;
import com.iitk.courseez.model.user;

@Service
public class profCourseServicesImpl implements profCourseServices{
    @Autowired
    profCourseDao profCourseDao;

    @Autowired
    userDao userDao;

    @Override
    public user GetProfFromCourseId(int courseId){
        profCourse profOfCourse = profCourseDao.findByCourseId(courseId);
        user profUser = userDao.findByUserId(profOfCourse.getUserId());
        return profUser;
    }
}
