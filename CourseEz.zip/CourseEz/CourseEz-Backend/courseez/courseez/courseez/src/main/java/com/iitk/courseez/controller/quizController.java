package com.iitk.courseez.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iitk.courseez.dao.mcqQuestionDao;
import com.iitk.courseez.dao.numQuestionDao;
import com.iitk.courseez.dao.quizCourseDao;
import com.iitk.courseez.dao.quizMarksDao;
import com.iitk.courseez.dao.quizQuestionidDao;
import com.iitk.courseez.model.addQuizBody;
import com.iitk.courseez.model.mcqQuestion;
import com.iitk.courseez.model.numQuestion;
import com.iitk.courseez.model.quizCourse;
import com.iitk.courseez.model.quizMarks;
import com.iitk.courseez.model.quizQuestionid;
import com.iitk.courseez.services.mcqQuestionServices;
import com.iitk.courseez.services.numQuestionServices;
import com.iitk.courseez.services.quizMarksServices;


@RestController
public class quizController {
    
    @Autowired
    ObjectMapper mapper;
    

    @Autowired
    quizMarksDao quizMarksDao;

    @Autowired
    mcqQuestionServices mcqQuestionServices;

    @Autowired
    quizMarksServices quizMarksServices;

    @Autowired
    numQuestionServices numQuestionServices;

    @Autowired
    numQuestionDao numQuestionDao;

    @Autowired
    mcqQuestionDao mcqQuestionDao;

    @Autowired
    quizQuestionidDao quizQuestionIdDao;

    @Autowired
    quizCourseDao quizCourseDao;

    @PostMapping("/getmcqs")
    @CrossOrigin
    public List<mcqQuestion> getMcqs(@RequestParam Integer quizId) {
        List<mcqQuestion> questions = new ArrayList<mcqQuestion>();
        questions = mcqQuestionServices.GetAllMcqQuestions(quizId);
        return questions;
    }

    @PostMapping("/getnums")
    @CrossOrigin
    public List<numQuestion> getNums(@RequestParam Integer quizId) {
        List<numQuestion> questions = new ArrayList<numQuestion>();
        questions = numQuestionServices.GetAllNumQuestions(quizId);
        return questions;
    }

    @PostMapping("/attempted")
    @CrossOrigin
    public void updateAttempted(@RequestParam Integer quizId, @RequestParam Integer userId) {
        quizMarksDao.save(new quizMarks(userId, quizId,0,0,1));
    }

    @PostMapping("/submitted")
    @CrossOrigin
    public void updateSubmitted(@RequestParam Integer quizId, @RequestParam Integer userId, @RequestParam Integer marks) {
        quizMarksServices.updateMarks(userId, quizId, marks);
    }

    @PostMapping("/addquiz")
    @CrossOrigin
    public Integer addMcqQues(@RequestBody addQuizBody aqb) {
        quizCourse newQuiz = quizCourseDao.save(new quizCourse(aqb.courseId));
        
        List<mcqQuestion> mcqQuestions = aqb.mcqQuestions;
        for(int i = 0; i < mcqQuestions.size(); i++) {
            mcqQuestions.set(i, mcqQuestionDao.save(mcqQuestions.get(i)));
            quizQuestionIdDao.save(new quizQuestionid(newQuiz.getQuizId(), mcqQuestions.get(i).getQuestionId(), 1));
        }

        List<numQuestion> numQuestions = aqb.numQuestions;
        for(int i = 0; i < numQuestions.size(); i++) {
            numQuestions.set(i, numQuestionDao.save(numQuestions.get(i)));
            quizQuestionIdDao.save(new quizQuestionid(newQuiz.getQuizId(), numQuestions.get(i).getQuestionId(), 0));
        }

        return newQuiz.getQuizId();
    }

    @PostMapping("/addmcqques")
    @CrossOrigin
    public Integer addMcqQues(@RequestBody List<mcqQuestion> mcqQuestions, @RequestParam Integer courseId) {
        quizCourse newQuiz = quizCourseDao.save(new quizCourse(courseId));
        
        for(int i = 0; i < mcqQuestions.size(); i++) {
            mcqQuestions.set(i, mcqQuestionDao.save(mcqQuestions.get(i)));
            quizQuestionIdDao.save(new quizQuestionid(newQuiz.getQuizId(), mcqQuestions.get(i).getQuestionId(), 1));
        }

        return newQuiz.getQuizId();
    }

    @PostMapping("/addnumques")
    @CrossOrigin
    public Integer addNujQues(@RequestBody List<numQuestion> numQuestions, @RequestParam Integer quizId) {
        for(int i = 0; i < numQuestions.size(); i++) {
            numQuestions.set(i, numQuestionDao.save(numQuestions.get(i)));
            quizQuestionIdDao.save(new quizQuestionid(quizId, numQuestions.get(i).getQuestionId(), 0));
        }

        return quizId;
    }
    
}
