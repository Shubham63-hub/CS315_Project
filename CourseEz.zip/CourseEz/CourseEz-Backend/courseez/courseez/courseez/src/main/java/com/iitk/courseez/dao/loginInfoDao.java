package com.iitk.courseez.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iitk.courseez.model.loginInfo;

@Repository
public interface loginInfoDao extends JpaRepository<loginInfo, Integer>{
    public loginInfo findByEmailId(String emailId);
}