package com.iitk.courseez.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iitk.courseez.model.numQuestion;

@Repository
public interface numQuestionDao extends JpaRepository<numQuestion, Integer>  {
    public numQuestion findByQuestionId(int questionId);
}
