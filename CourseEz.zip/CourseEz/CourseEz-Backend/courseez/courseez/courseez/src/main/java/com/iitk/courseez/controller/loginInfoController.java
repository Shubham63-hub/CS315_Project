package com.iitk.courseez.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.iitk.courseez.model.loginInfo;
import com.iitk.courseez.services.loginInfoServices;

@RestController
public class loginInfoController {
    @Autowired
    ObjectMapper mapper;

    @Autowired
    private loginInfoServices loginInfoServices;
    
    @PostMapping("/login")
    @CrossOrigin
    public ObjectNode checkLogin(@RequestBody loginInfo loginInfo){
        loginInfo check = loginInfoServices.GetLoginInfo(loginInfo.getEmailId());
        ObjectNode returnJson = mapper.createObjectNode();
        if(check == null){
            returnJson.put("status", false);
            returnJson.put("isProf", 0);
            returnJson.put("userId", 0);
            return returnJson;
        }
        if(check.getPassword().equals(loginInfo.getPassword())) {
            returnJson.put("status", true);
            returnJson.put("isProf", check.getIsProf());
            returnJson.put("userId", check.getId());
        }
        else{
            returnJson.put("status", false);
            returnJson.put("isProf", 0);
            returnJson.put("userId", 0);
        }
        return returnJson;
    }
}
