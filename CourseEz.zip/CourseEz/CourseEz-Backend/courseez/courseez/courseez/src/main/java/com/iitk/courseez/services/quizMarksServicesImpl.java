package com.iitk.courseez.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iitk.courseez.dao.quizMarksDao;
import com.iitk.courseez.model.quizMarks;

@Service
public class quizMarksServicesImpl implements quizMarksServices {
    @Autowired
    quizMarksDao quizMarksDao;

    @Override
    public int getQuizRecordIndex(int userId, int quizId) {
        List<quizMarks> quizes = quizMarksDao.findByUserId(userId);
        for(int i=0;i<quizes.size();i++) {
            if(quizes.get(i).getQuizId() == quizId)
                return i;
        }
        return -1;
    }

    @Override
    public void updateMarks(int userId, int quizId, int marks) {
        quizMarks quizMarks = quizMarksDao.findByUserIdAndQuizId(userId, quizId);
        if(quizMarks != null){
            quizMarksDao.deleteById(quizMarks.getId());
            quizMarksDao.save(new quizMarks(userId, quizId, marks, 1, 1));
        }
    }

   
}
