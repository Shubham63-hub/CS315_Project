package com.iitk.courseez.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iitk.courseez.model.profCourse;

@Repository
public interface profCourseDao extends JpaRepository<profCourse, Integer> {
    public List<profCourse> findByUserId(int userId);

    public profCourse findByCourseId(int courseId);
}
