package com.iitk.courseez.services;

import java.util.List;

import com.iitk.courseez.model.course;

public interface userCourseServices {
    public abstract List<course> GetAllCourses(int userId);
}
