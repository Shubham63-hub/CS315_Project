package com.iitk.courseez.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iitk.courseez.dao.loginInfoDao;
import com.iitk.courseez.model.loginInfo;

@Service
public class loginInfoServicesImpl implements loginInfoServices {
    @Autowired
    loginInfoDao loginInfoDao;

    @Override
    public loginInfo GetLoginInfo(String emailId){
        return loginInfoDao.findByEmailId(emailId);
    }
}
