package com.iitk.courseez.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class user {
    public user() {}
    
    @Id
    private int id;
    
    private int userId;
    private String name;
    private String rollNo;
    private String dept;
    private String programme;

    public user(int id, int userId, String name, String rollNo, String dept, String programme) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.rollNo = rollNo;
        this.dept = dept;
        this.programme = programme;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getRollNo() {
        return rollNo;
    }
    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }
    public String getDept() {
        return dept;
    }
    public void setDept(String dept) {
        this.dept = dept;
    }
    public String getProgramme() {
        return programme;
    }
    public void setProgramme(String programme) {
        this.programme = programme;
    }

}
