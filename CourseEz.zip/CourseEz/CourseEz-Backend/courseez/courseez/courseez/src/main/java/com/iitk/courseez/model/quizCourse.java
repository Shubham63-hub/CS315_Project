package com.iitk.courseez.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class quizCourse {
    public quizCourse(){};

    // @Id
    // @GeneratedValue
    // private int id;

    @Id
    @GeneratedValue
    private int quizId;

    private int courseId;

    public quizCourse(int courseId) {
        this.courseId = courseId;
    }
    public int getQuizId() {
        return quizId;
    }
    public void setQuizId(int quizId) {
        this.quizId = quizId;
    }
    public int getCourseId() {
        return courseId;
    }
    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }
}
