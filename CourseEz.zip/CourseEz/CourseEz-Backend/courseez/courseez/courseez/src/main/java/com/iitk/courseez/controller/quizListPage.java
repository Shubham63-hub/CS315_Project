package com.iitk.courseez.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.iitk.courseez.dao.quizCourseDao;
import com.iitk.courseez.dao.quizMarksDao;
import com.iitk.courseez.model.quizCourse;
import com.iitk.courseez.model.quizMarks;

@RestController
public class quizListPage {
    @Autowired
    quizCourseDao quizCourseDao;

    @Autowired
    quizMarksDao quizMarksDao;

    @PostMapping("/getquizzes")
    @CrossOrigin
    public List<quizCourse> getAllQuizzes(@RequestParam Integer courseId){
        List<quizCourse> getquizzes = quizCourseDao.findByCourseId(courseId);
        return getquizzes;
    }

    @PostMapping("/getmarks")
    @CrossOrigin
    public List<quizMarks> getAllMarks(@RequestParam Integer courseId,@RequestParam Integer userId ){
        List<quizCourse> getquizzes = quizCourseDao.findByCourseId(courseId);
        List<quizMarks> allMarks = new ArrayList<quizMarks>();
        for(int i = 0 ; i < getquizzes.size(); i++){
            quizMarks quizMarks = quizMarksDao.findByUserIdAndQuizId(userId, getquizzes.get(i).getQuizId());
            if(quizMarks == null){
                allMarks.add(new quizMarks(userId, getquizzes.get(i).getQuizId() , 0, 0, 0));
            }
            else{
                allMarks.add(quizMarks);
            }
        }
        return allMarks;
    }


    @PostMapping("/attemptQuiz")
    @CrossOrigin
    public void addAttemptQuiz(@RequestParam Integer quizId, @RequestParam Integer userId){
        quizMarksDao.save(new quizMarks(userId, quizId, 0, 1, 1));
    }

}
