package com.iitk.courseez.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iitk.courseez.model.course;


@Repository
public interface courseDao extends JpaRepository<course, Integer> {
    public course findByCourseId(int courseId);
    public course findByCourseNo(String courseNo);
}
