package com.iitk.courseez.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iitk.courseez.model.quizMarks;

@Repository
public interface quizMarksDao extends JpaRepository<quizMarks, Integer>  {
    public List<quizMarks> findByUserId(int userId);
    public quizMarks findByUserIdAndQuizId(int userId, int quizId);
    public List<quizMarks> findByQuizId(int quizId);
    // @Modifying
    // // @Transactional
    // @Query("update quiz_marks q set q.is_submitted = 1, q.marks = :marks where q.id = :id")
    // public void updateSubmitted(@Param("id") int id, @Param("marks") int marks);
}
