package com.iitk.courseez.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iitk.courseez.model.userCourse;

@Repository
public interface userCourseDao extends JpaRepository<userCourse, Integer> {
    public List<userCourse> findByUserId(int userId);
    public userCourse findByUserIdAndCourseId(int userId, int courseId);
}
