package com.iitk.courseez.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iitk.courseez.model.quizQuestionid;
import java.util.List;


@Repository
public interface quizQuestionidDao extends JpaRepository<quizQuestionid, Integer>  {
    public List<quizQuestionid> findByQuizId(int quizId);
}
