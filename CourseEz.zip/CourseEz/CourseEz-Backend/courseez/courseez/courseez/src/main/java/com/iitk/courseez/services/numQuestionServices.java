package com.iitk.courseez.services;
import java.util.List;

import com.iitk.courseez.model.numQuestion;


public interface numQuestionServices {
    public abstract List<numQuestion> GetAllNumQuestions(int quizId);
}
