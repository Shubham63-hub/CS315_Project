package com.iitk.courseez.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class quizQuestionid {
    public quizQuestionid() {}

    @Id
    @GeneratedValue
    private int id;

    private int quizId;
    private int questionId;
    private int isMcq;
    
    public int getIsMcq() {
        return isMcq;
    }
    public void setIsMcq(int isMcq) {
        this.isMcq = isMcq;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getQuizId() {
        return quizId;
    }
    public void setQuizId(int quizId) {
        this.quizId = quizId;
    }
    public int getQuestionId() {
        return questionId;
    }
    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }
    public quizQuestionid(int quizId, int questionId, int isMcq) {
        this.quizId = quizId;
        this.questionId = questionId;
        this.isMcq = isMcq;
    }
}
