package com.iitk.courseez.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class numQuestion {
    public numQuestion() {}

    @Id
    @GeneratedValue
    private int questionId;
    
    private Double solution;
    private String description;

    public numQuestion(Double solution, String description) {
        this.solution = solution;
        this.description = description;
    }
    
    public int getQuestionId() {
        return questionId;
    }

    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }

    public Double getsolution() {
        return solution;
    }

    public void setsolution(Double solution) {
        this.solution = solution;
    }

    public String getdescription() {
        return description;
    }

    public void setdescription(String description) {
        this.description = description;
    }

    

}
